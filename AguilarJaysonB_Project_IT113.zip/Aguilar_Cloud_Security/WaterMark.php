<?php

//index.php

$connect = new PDO("mysql:host=localhost;dbname=Aguilar_Cloud_Security", "root", "");

$message = '';

if(isset($_POST["upload"]))
{
  if(!empty($_FILES["select_image"]["name"]))
  { 
    $extension = pathinfo($_FILES["select_image"]["name"],PATHINFO_EXTENSION);
    
    $allow_extension = array('jpg','png','jpeg');

    $file_name = uniqid() . '.' . $extension;

    $upload_location = 'upload/' . $file_name;

    if(in_array($extension, $allow_extension))
    {
      $image_size = $_FILES["select_image"]["size"];
      if($image_size < 2 * 1024 * 1024)
      {
        if(move_uploaded_file($_FILES["select_image"]["tmp_name"], $upload_location))
        { 
          
          $watermark_image = imagecreatefrompng('img/LogoLock.png');
          if($extension == 'jpg' || $extension == 'jpeg')
          {
            $image = imagecreatefromjpeg($upload_location);
          }

          if($extension == 'png')
          {
            $image = imagecreatefrompng($upload_location);
          }

          $margin_right = 10; 
          $margin_bottom = 10;

          $watermark_image_width = imagesx($watermark_image); 
          $watermark_image_height = imagesy($watermark_image);  

          imagecopy($image, $watermark_image, imagesx($image) - $watermark_image_width - $margin_right, imagesy($image) - $watermark_image_height - $margin_bottom, 0, 0, $watermark_image_width, $watermark_image_height); 

          imagepng($image, $upload_location); 

          imagedestroy($image);
          if(file_exists($upload_location))
          { 
            $message = "Image Uploaded with Watermark";
            $data = array(
              ':image_name'   =>  $file_name
            );
            $query = "
            INSERT INTO images_table 
            (image_name, upload_datetime) 
            VALUES (:image_name, now())
            ";
            $statement = $connect->prepare($query);
            $statement->execute($data);
          }
          else
          { 
            $message = "There is some error, try again";
          }
        }
        else
        {
          $message = "There is some error, try again";
        }
      }
      else
      {
        $message = "Selected Image Size is very big";
      }      
    }
    else
    {
      $message = 'Only .jpg, .png and .jpeg image file allowed to upload';
    }
  }
  else
  { 
    $message = 'Please select Image';
  } 
}

$query = "
SELECT * FROM images_table 
ORDER BY image_id DESC
";

$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();



?>

<!DOCTYPE html>
<html>
  <head>
    <title>Aguilar Cloud Security</title>
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
      <center>
        <img src="img/CompName.png" height="150px" weight="150px">
          <table class="Table1">
              <tr>
                  <td class="Header1">
                    Explation:
                  </td>
                  <td class="Header1">
                  Add Wartermark to an Image
                  </td>
              </tr>
              <tr>
                  <td>
                          This is simple system let the image file secured using watermark it work in simple way, 
                            <ul>
                                <li>By uploading the file the new creation image is going to process.</li>
                                <li>The Company logo make the image file categories LOCK.</li>
                                <li>The Company logo is the watermark and making the file lock.</li>
                                <li>If the image file let to download watermark will be the sign which it comes.</li>
                            </ul>
                      </p>
                    </td>
                    <td>
                      <table class="Table1">
                          <tr>
                            <td>
                                <?php
                                if($message != '')
                                {
                                  echo '
                                  <div class="alert">
                                  '.$message.'
                                  </div>
                                  ';
                                }
                                ?>
                            </td>
                          </tr>
                          <tr>
                                <td>
                                  <form method="post" enctype="multipart/form-data">
                                   <input type="file" name="select_image"/ class="custom-file-input">
                                </td>
                          </tr>
                          <tr>
                                <td>
                                 <input type="submit" name="upload" class="btn btn-primary" value="Upload" />
                                </td>
                                </form>
                          </tr>
                      </table>
                    </td>
              </tr>
          </table>
      </center>
      <br>
      <center>
      <table weight="300px" class="Table1">
              <tr>
                  <td class="Header1">
                  Uploaded Image with Watermark
                  </td>
                  </tr>
                  <tr>
                  <td class="Header1">
                  <?php
                        foreach($result as $row)
                        {
                          echo '
                            <img src="upload/'.$row["image_name"].'" height="100px" weight="100px"/ class="image">
                          ';
                        }
                    ?>
                  </td>
              </tr>
      </center>
  </body>
</html>